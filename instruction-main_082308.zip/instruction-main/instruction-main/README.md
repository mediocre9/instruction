# Instructions

1. `Fork` the repository (means copy the original repository to your account).
2. Download the project, and make some changes to it.
3. Click on `Add File` Button and upload the file to your forked repo.
4. Then click on `Contribute` button and open pull request.
5. Wait for code review. 
