#include <iostream>
using namespace std;

int main() {
    
    cout << "Mediocre is world biggest bot";

    cin.get();

    return 0;
}

